A multipage Space Tourism website. It is a concept website that gives you the opportunity to visit other planets in space!

Live Project: https://spacetours.netlify.app/

Built with: Javascript Es6+, HTML5, CSS3
